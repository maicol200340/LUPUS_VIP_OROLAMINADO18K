/* =========================================================
   LUPUS VIP — animaciones GSAP + ScrollTrigger
   ========================================================= */
if (window.gsap && window.ScrollTrigger) gsap.registerPlugin(ScrollTrigger);

/** Divide un título en palabras con máscara de revelado (respeta <br>). */
function splitWords(el) {
  const label = el.textContent.replace(/\s+/g, " ").trim();
  const lines = el.innerHTML.split(/<br\s*\/?>/i).map(l => l.replace(/<[^>]+>/g, "").trim());
  el.setAttribute("aria-label", label);
  el.innerHTML = lines
    .map(line => line.split(/\s+/).map(w =>
      `<span class="w" aria-hidden="true"><span class="w-i${/^18K$/i.test(w) ? " gold" : ""}">${w}</span></span>`
    ).join(" "))
    .join("<br>");
  return el.querySelectorAll(".w-i");
}

function initScrollAnimations() {
  const mm = gsap.matchMedia();

  mm.add(
    {
      desktop: "(min-width: 768px)",
      mobile: "(max-width: 767px)",
      reduce: "(prefers-reduced-motion: reduce)"
    },
    (ctx) => {
      const { desktop, reduce } = ctx.conditions;
      if (reduce) return; // contenido visible, sin animaciones intensas

      /* ---- Parallax del hero (suave, solo escritorio) ---- */
      if (desktop) {
        const hero = { trigger: ".hero", start: "top top", end: "bottom top", scrub: true };
        gsap.to(".px-logo", { yPercent: -15, ease: "none", scrollTrigger: hero });
        gsap.to(".px-text", { yPercent: -5, ease: "none", scrollTrigger: hero });
        gsap.to(".px-gold", { yPercent: 10, ease: "none", scrollTrigger: hero });
      }

      /* ---- Títulos: revelado palabra por palabra ---- */
      gsap.utils.toArray("[data-split]").forEach((title) => {
        const words = splitWords(title);
        gsap.from(words, {
          yPercent: 115, duration: 1.1, ease: "power4.out", stagger: 0.07,
          scrollTrigger: { trigger: title, start: "top 85%", once: true }
        });
      });

      /* ---- Párrafos ---- */
      gsap.utils.toArray("[data-reveal]").forEach((p) => {
        gsap.from(p, {
          y: 24, opacity: 0, duration: 1, ease: "power3.out",
          scrollTrigger: { trigger: p, start: "top 90%", once: true }
        });
      });

      /* ---- Expansión de imágenes / marcos al hacer scroll ---- */
      const expandFrom = { scale: 0.75, opacity: 0.4, clipPath: "inset(10% round 40px)" };
      const expandTo = { scale: 1, opacity: 1, clipPath: "inset(0% round 10px)", ease: "none" };

      gsap.utils.toArray("[data-expand]").forEach((el) => {
        gsap.fromTo(el, expandFrom, {
          ...expandTo,
          scrollTrigger: { trigger: el, start: "top 88%", end: "top 40%", scrub: 1 }
        });
      });

      gsap.utils.toArray(".card").forEach((card) => {
        const media = card.querySelector(".card__media");
        gsap.fromTo(media, expandFrom, {
          ...expandTo,
          scrollTrigger: { trigger: card, start: "top 88%", end: "top 42%", scrub: 1 }
        });
        gsap.from(card.querySelector(".card__body"), {
          opacity: 0, y: 20, duration: 0.9, ease: "power3.out",
          scrollTrigger: { trigger: card, start: "top 70%", once: true }
        });
      });

      /* ---- Frase "NO ES SOLO UNA JOYA." ---- */
      const st = gsap.timeline({
        scrollTrigger: { trigger: ".statement", start: "top 70%", end: "center 45%", scrub: 1 }
      });
      st.from(".statement__label", { opacity: 0, y: 16 })
        .from(".statement__line:nth-child(1)", { opacity: 0.05, xPercent: -8 }, "<0.2")
        .from(".statement__line:nth-child(2)", { opacity: 0.05, xPercent: 8 }, ">-0.1")
        .from(".statement__sub", { opacity: 0, y: 20 }, ">-0.05");

      /* ---- Video: entra desde el fondo y se expande ---- */
      gsap.fromTo("#videoFrame",
        { scale: desktop ? 0.75 : 0.85, opacity: 0, borderRadius: 40 },
        {
          scale: 1, opacity: 1, borderRadius: 10, ease: "none",
          scrollTrigger: { trigger: "#videoStage", start: "top 92%", end: "top 28%", scrub: 1 }
        });

      /* ---- Proceso: línea dorada que se dibuja + pasos ---- */
      const steps = gsap.utils.toArray(".step");
      const ptl = gsap.timeline({
        scrollTrigger: { trigger: "#steps", start: "top 72%", end: "bottom 60%", scrub: 1 }
      });
      if (desktop) ptl.fromTo(".steps__fill", { scaleX: 0 }, { scaleX: 1, duration: steps.length, ease: "none" }, 0);
      else ptl.fromTo(".steps__fill", { scaleY: 0 }, { scaleY: 1, duration: steps.length, ease: "none" }, 0);
      steps.forEach((s, i) => ptl.from(s, { opacity: 0, y: 30, duration: 0.8 }, i * 0.95));

      /* ---- Próximamente ---- */
      gsap.to(".coming__ring", {
        rotation: 40, ease: "none",
        scrollTrigger: { trigger: ".coming", start: "top bottom", end: "bottom top", scrub: true }
      });
      gsap.from(".coming__big", {
        opacity: 0, yPercent: 30, duration: 1.2, ease: "power3.out",
        scrollTrigger: { trigger: ".coming", start: "top 65%", once: true }
      });

      /* ---- Redes y QR ---- */
      gsap.from(".social-card", {
        opacity: 0, y: 30, duration: 1, stagger: 0.15, ease: "power3.out",
        scrollTrigger: { trigger: ".social__grid", start: "top 80%", once: true }
      });
      gsap.from("#qr", {
        scale: 0.8, opacity: 0, duration: 1.3, ease: "power3.out",
        scrollTrigger: { trigger: "#qr", start: "top 85%", once: true }
      });
    }
  );

  document.fonts && document.fonts.ready.then(() => ScrollTrigger.refresh());
  window.addEventListener("load", () => ScrollTrigger.refresh());
}
