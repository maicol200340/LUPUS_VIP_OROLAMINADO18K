/* =========================================================
   LUPUS VIP — lógica principal
   ========================================================= */
(() => {
  const C = window.LUPUS_CONFIG;
  const $ = (s, r = document) => r.querySelector(s);
  const $$ = (s, r = document) => Array.from(r.querySelectorAll(s));
  const reduceMotion = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
  const isFinePointer = window.matchMedia("(hover:hover) and (pointer:fine)").matches;
  const hasGSAP = typeof window.gsap !== "undefined" && typeof window.ScrollTrigger !== "undefined";

  /* ---------- Config → DOM ---------- */
  function whatsappUrl(message) {
    const digits = String(WHATSAPP_NUMBER).replace(/\D/g, "");
    const number = digits || WHATSAPP_NUMBER;
    return `https://wa.me/${number}?text=${encodeURIComponent(message)}`;
  }

  function applyConfig() {
    $$("[data-whatsapp]").forEach((a) => {
      a.href = whatsappUrl(a.dataset.whatsapp === "info" ? WHATSAPP_MESSAGE_INFO : WHATSAPP_MESSAGE);
    });
    $$("[data-social]").forEach((a) => { a.href = C.social[a.dataset.social].url; });
    $$("[data-social-handle]").forEach((el) => { el.textContent = C.social[el.dataset.socialHandle].handle; });
    $$("[data-logo]").forEach((img) => { img.src = C.assets.logo; });
    $(".qr__img").src = C.assets.qr;
    $$("[data-text]").forEach((el) => {
      const t = C.texts && C.texts[el.dataset.text];
      if (t) el.textContent = t;
    });
  }

  function buildProducts() {
    const grid = $("#productGrid");
    grid.innerHTML = C.products.map((p) => {
      const media = p.image
        ? `<img src="${p.image}" alt="${p.alt || p.name}" loading="lazy" decoding="async">`
        : `<div class="card__ph" role="img" aria-label="Espacio para foto: ${p.name} — próximamente"><i></i><i></i><span>PRÓXIMAMENTE</span></div>`;
      return `<article class="card"><div class="card__media">${media}</div><div class="card__body"><h3>${p.name}</h3><p>${p.desc}</p></div></article>`;
    }).join("");
  }

  function buildVideo() {
    const { src, poster } = C.video || {};
    if (!src) return;
    const stage = $("#videoStage");
    if (poster) stage.style.setProperty("--poster", `url("${poster}")`);
    const v = document.createElement("video");
    v.setAttribute("autoplay", ""); v.setAttribute("muted", ""); v.setAttribute("loop", "");
    v.setAttribute("playsinline", ""); v.setAttribute("preload", "metadata");
    v.setAttribute("aria-label", "Video del proceso de elaboración de una manilla de balinería diamantada 18K");
    if (poster) v.poster = poster;
    v.src = src;
    v.muted = true; v.playsInline = true;
    $("#videoPh").remove();
    $("#videoFrame").prepend(v);
    // Reproduce solo cuando es visible (ahorra datos y batería)
    if ("IntersectionObserver" in window) {
      new IntersectionObserver(([e]) => {
        if (e.isIntersecting) v.play().catch(() => {}); else v.pause();
      }, { threshold: 0.25 }).observe(v);
    }
  }

  /* ---------- Header + menú móvil ---------- */
  function initHeader() {
    const header = $("#header");
    const onScroll = () => header.classList.toggle("is-scrolled", window.scrollY > 40);
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });

    const burger = $("#burger"), menu = $("#mobileMenu");
    const setMenu = (open) => {
      burger.setAttribute("aria-expanded", String(open));
      burger.setAttribute("aria-label", open ? "Cerrar menú" : "Abrir menú");
      menu.classList.toggle("is-open", open);
      menu.setAttribute("aria-hidden", String(!open));
      document.body.classList.toggle("menu-open", open);
    };
    burger.addEventListener("click", () => setMenu(burger.getAttribute("aria-expanded") !== "true"));
    $$("a", menu).forEach((a) => a.addEventListener("click", () => setMenu(false)));
    document.addEventListener("keydown", (e) => { if (e.key === "Escape") setMenu(false); });
    window.matchMedia("(min-width:1024px)").addEventListener("change", (e) => { if (e.matches) setMenu(false); });
  }

  /* ---------- Cursor premium (solo escritorio) ---------- */
  function initCursor() {
    if (!isFinePointer || !hasGSAP) return;
    const el = $(".cursor");
    const xTo = gsap.quickTo(el, "x", { duration: 0.35, ease: "power3" });
    const yTo = gsap.quickTo(el, "y", { duration: 0.35, ease: "power3" });
    window.addEventListener("mousemove", (e) => { el.classList.add("is-on"); xTo(e.clientX); yTo(e.clientY); }, { passive: true });
    document.addEventListener("mouseleave", () => el.classList.remove("is-on"));
    document.addEventListener("mouseover", (e) => {
      el.classList.toggle("is-hover", !!e.target.closest("a, button, .card, .social-card, .qr"));
    });
  }

  /* ---------- Partículas doradas del hero ---------- */
  function initParticles() {
    const canvas = $("#particles");
    if (!canvas || reduceMotion) return;
    const ctx = canvas.getContext("2d");
    const mobile = window.innerWidth < 768;
    const COUNT = mobile ? 18 : 42;
    let w, h, dpr, parts = [], raf = null, visible = true;

    const size = () => {
      dpr = Math.min(window.devicePixelRatio || 1, 2);
      w = canvas.clientWidth; h = canvas.clientHeight;
      canvas.width = w * dpr; canvas.height = h * dpr;
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    };
    const spawn = (initial) => ({
      x: Math.random() * w, y: initial ? Math.random() * h : h + 10,
      r: Math.random() * 1.6 + 0.5, v: Math.random() * 0.25 + 0.08,
      a: Math.random() * 0.5 + 0.15, t: Math.random() * Math.PI * 2, s: Math.random() * 0.02 + 0.006
    });
    const tick = () => {
      if (!visible) { raf = null; return; }
      ctx.clearRect(0, 0, w, h);
      for (const p of parts) {
        p.y -= p.v; p.t += p.s;
        if (p.y < -10) Object.assign(p, spawn(false));
        const tw = (Math.sin(p.t) + 1) / 2;
        ctx.beginPath();
        ctx.fillStyle = `rgba(243,210,122,${p.a * (0.35 + tw * 0.65)})`;
        ctx.shadowColor = "rgba(243,210,122,.8)"; ctx.shadowBlur = 8;
        ctx.arc(p.x, p.y, p.r, 0, Math.PI * 2); ctx.fill();
      }
      raf = requestAnimationFrame(tick);
    };
    size();
    parts = Array.from({ length: COUNT }, () => spawn(true));
    window.addEventListener("resize", size);
    new IntersectionObserver(([e]) => {
      visible = e.isIntersecting;
      if (visible && !raf) raf = requestAnimationFrame(tick);
    }).observe(canvas);
    raf = requestAnimationFrame(tick);
  }

  /* ---------- Entrada del hero ---------- */
  function heroEntrance() {
    if (!hasGSAP || reduceMotion) return;
    const tl = gsap.timeline({ defaults: { ease: "power3.out" } });
    tl.from(".header", { yPercent: -100, opacity: 0, duration: 1 }, 0)
      .from(".hero__logo", { opacity: 0, scale: 0.92, duration: 1.4 }, 0)
      .from(".hero__tag, .hero h1, .hero__sub, .hero__actions", { opacity: 0, y: 26, duration: 1, stagger: 0.14 }, 0.35)
      .from(".scroll-hint", { opacity: 0, duration: 1 }, 1.2);
    // Brillo dorado recorriendo el logo, lento y recurrente
    gsap.fromTo(".hero .shine-band", { xPercent: -140, opacity: 1 },
      { xPercent: 300, duration: 2.6, ease: "power2.inOut", repeat: -1, repeatDelay: 5, delay: 1.5 });
  }

  /* ---------- Intro cinematográfica ---------- */
  function initIntro() {
    const intro = $("#intro");
    const finish = () => {
      document.body.classList.remove("is-loading");
      intro.remove();
      if (hasGSAP) { initScrollAnimations(); ScrollTrigger.refresh(); }
      heroEntrance();
    };

    const seen = sessionStorage.getItem("lupus-intro");
    if (!hasGSAP || reduceMotion || seen) {
      finish();
      return;
    }

    const enterBtn = $("#introEnter");
    gsap.set(".intro__logo", { opacity: 0, scale: 0.85 });
    gsap.set(".intro__line, .intro__by, .intro__cta", { opacity: 0, y: 14 });

    let leaving = false;
    const leave = () => {
      if (leaving) return; leaving = true;
      try { sessionStorage.setItem("lupus-intro", "1"); } catch (_) {}
      gsap.timeline({ onComplete: finish })
        .to(".intro__stage", { scale: 1.08, opacity: 0, duration: 0.9, ease: "power2.in" })
        .to(intro, { clipPath: "inset(0 0 100% 0)", duration: 1.1, ease: "power4.inOut" }, "-=0.5");
    };
    enterBtn.addEventListener("click", leave);

    const tl = gsap.timeline({ defaults: { ease: "power3.out" } });
    tl.to(".intro__logo", { opacity: 1, scale: 1, duration: 1.5 })
      .fromTo(".intro .shine-band", { xPercent: -140, opacity: 1 }, { xPercent: 300, duration: 1.6, ease: "power2.inOut" }, 0.6)
      .to(".intro__line", { opacity: 1, y: 0, duration: 0.9 }, 1.5)
      .to(".intro__by", { opacity: 1, y: 0, duration: 0.9 }, 2.1)
      .to(".intro__cta", { opacity: 1, y: 0, duration: 0.8, onComplete: () => enterBtn.focus({ preventScroll: true }) }, 2.7)
      .call(() => gsap.delayedCall(2.2, leave), null, 3.4); // avanza solo si no se hace clic
  }

  /* ---------- Arranque ---------- */
  document.addEventListener("DOMContentLoaded", () => {
    applyConfig();
    buildProducts();
    buildVideo();
    initHeader();
    initCursor();
    initParticles();
    initIntro();
  });
})();
