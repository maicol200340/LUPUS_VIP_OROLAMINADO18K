/* =========================================================
   LUPUS VIP — CONFIGURACIÓN EDITABLE
   Cambia aquí el número de WhatsApp, redes, video, textos,
   productos y fotos. No hace falta tocar el resto del código.
   ========================================================= */

// ---- WhatsApp (único lugar donde se define) ----------------
// Solo números, con indicativo de país y sin "+". Ej: Colombia → "573001234567"
const WHATSAPP_NUMBER = "AQUI_NUMERO";
const WHATSAPP_MESSAGE =
  "Hola, quiero recibir asesoría personalizada sobre LUPUS VIP Oro Laminado 18K.";
// Mensaje para el botón "Quiero recibir información"
const WHATSAPP_MESSAGE_INFO =
  "Hola, quiero recibir información sobre la nueva colección de LUPUS VIP Oro Laminado 18K.";

window.LUPUS_CONFIG = {
  /* ---- LOGO y QR ---- */
  assets: {
    logo: "assets/images/logo-dark.png",      // logo para secciones oscuras
    qr: "assets/images/qr-whatsapp.png"
  },

  /* ---- REDES ---- */
  social: {
    instagram: {
      handle: "@lupus_vip",
      url: "https://www.instagram.com/lupus_vip?stkn=NzZlaGhucjgzcnN4"
    },
    tiktok: {
      handle: "@lupus_vip_orolaminado18k",
      url: "https://www.tiktok.com/@lupus_vip_orolaminado18k?_r=1&_t=ZS-9ANFDx2bJtV"
    }
  },

  /* ---- VIDEO de balinería diamantada ----
     src: ruta del MP4. Déjalo vacío ("") para mostrar el placeholder
     "VIDEO DEL PROCESO — PRÓXIMAMENTE".                              */
  video: {
    src: "assets/videos/proceso-balineria.mp4",
    poster: "assets/images/video-poster.jpg"
  },

  /* ---- TEXTOS (opcional: sobrescriben los del HTML por clave) ---- */
  texts: {
    slogan: "Elegancia que deja huella.",
    heroSub:
      "Joyería en oro laminado 18K diseñada para quienes buscan presencia, estilo y exclusividad.",
    aboutTitle: "EL LUJO ESTÁ EN LOS DETALLES",
    aboutP1:
      "En LUPUS VIP creemos que una joya no es simplemente un accesorio. Es una expresión de personalidad, presencia y estilo.",
    aboutP2:
      "Trabajamos con piezas de oro laminado 18K pensadas para quienes buscan elegancia, diseño y una apariencia sofisticada.",
    comingText: "Estamos preparando piezas diseñadas para destacar."
  },

  /* ---- PRODUCTOS ----
     Para agregar una foto real: escribe la ruta en "image"
     (ej. "assets/images/pulsera-balineria.jpg") y la tarjeta
     dejará de mostrar "PRÓXIMAMENTE" automáticamente.        */
  products: [
    { name: "Pulseras de balinería", desc: "Balinería diamantada en oro laminado 18K.", image: "", alt: "" },
    { name: "Pulseras de lugo",      desc: "Piezas de lugo con acabado en oro laminado 18K.", image: "", alt: "" },
    { name: "Anillas tejidas",       desc: "Anillas tejidas en oro laminado 18K.", image: "", alt: "" },
    { name: "Cadenas",               desc: "Cadenas en oro laminado 18K.", image: "", alt: "" },
    { name: "Herrajes",              desc: "Herrajes y complementos para tus piezas.", image: "", alt: "" },
    { name: "Dijes",                 desc: "Dijes en oro laminado 18K.", image: "", alt: "" }
  ]
};
