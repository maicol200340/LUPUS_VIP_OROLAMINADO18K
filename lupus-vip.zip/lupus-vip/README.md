# LUPUS VIP — Oro Laminado 18K

Abre `index.html` en el navegador (o sube la carpeta a cualquier hosting estático).
Necesita internet para cargar GSAP y las tipografías desde CDN.

## Qué editar (todo en `js/config.js`)
- `WHATSAPP_NUMBER`: tu número con indicativo, solo dígitos (ej. `573001234567`). Se usa en todos los botones.
- `WHATSAPP_MESSAGE` / `WHATSAPP_MESSAGE_INFO`: mensajes que se envían.
- `social`: enlaces y @ de Instagram y TikTok.
- `video.src`: ruta del MP4 (vacío = placeholder "PRÓXIMAMENTE").
- `products[].image`: ruta de la foto real; la tarjeta deja de decir "PRÓXIMAMENTE".
- `texts`: textos principales.

## Estructura
index.html · css/style.css · js/config.js · js/animations.js · js/main.js · assets/{images,videos,icons}
